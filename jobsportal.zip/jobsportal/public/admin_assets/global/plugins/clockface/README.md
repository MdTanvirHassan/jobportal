# Clockface 
Clock-like timepicker for Twitter Bootstrap.

## Demo, Docs and Download
See **http://vitalets.github.com/clockface**

## Contribution
Your support is appreciated. 
Please make pull requests on <code>dev</code> branch. Thank you!

## License
Copyright (c) 2012 Vitaliy Potapov  
Licensed under the MIT licenses.